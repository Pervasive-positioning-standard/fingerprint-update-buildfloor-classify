import pandas as pd
import numpy as np
import copy
def trans(Floor):
    if Floor==81:
        Floor=-1
    if Floor==82:
        Floor=-3
    if Floor==83:
        Floor=-4
    if Floor==84:
        Floor=-5
    if Floor==85:
        Floor=-7
    return Floor
def classify(user_signal):
    k=user_signal['mac']
    v=user_signal['rss']
    df = pd.read_csv('D:/vscode/mode3-server/mac_home.csv')
    #transfer usersignal into user
    BF_list=[]
    BF_scores=[]
    for i in range(len(user_signal)):
       for j in range(len(df['BuFloor'])):
           if k[i] in df['mac'][j]:
               BF=df['BuFloor'][j]
               BF_score=v[i]+105
               if len(BF_list)==0:
                   BF_list.append(BF)
                   BF_scores.append(BF_score)
               elif BF not in BF_list:
                   BF_list.append(BF)
                   BF_scores.append(BF_score)
               else:
                   for b in range(len(BF_list)):
                       if BF_list[b]==BF:
                          BF_scores[b]+=BF_score
    #print(BF_list)
    #print(BF_scores)
    t = copy.deepcopy(BF_scores)
    # 求m个最大的数值及其索引
    max_index = []
    for _ in range(3):
        number = max(t)
        index = t.index(number)
        t[index] = 0
        max_index.append(index)
    t = []
    C1=BF_list[max_index[0]]
    C2=BF_list[max_index[1]]
    C3=BF_list[max_index[2]]
    F1=trans(int(C1[-2:]))
    F2=trans(int(C2[-2:]))
    F3=trans(int(C3[-2:]))
    F=round((F1+F2+F3)/3)
    if F<10:
        F=str(0)+str(F)
    return C1[:-2],F
def modify(f):
    AP_location=[]
    for w in f:
        du=[]
        du.append(w['mac'])
        du.append(w['rssi'])
        AP_location.append(du)
    user=pd.DataFrame(AP_location)
    user.columns=['mac','rss']
    return user