import copy
import pandas as pd
def ap_inf(ap):
    f= open("D:/vscode/mode3-server/fingerprint/1F/fingerprint.txt", "r")
    AP_location=[]
    for x in f:
        i=0
        for w in x.split(" "):
            i=i+1
            if i>1:
                j=0
                du=copy.deepcopy(du1)
                for y in w.split(','):
                    j=j+1
                    if j==1:
                       du.append(y)
                    if j==2:
                        du.append(float(y))
                AP_location.append(du)
            else:
                du1=[]
                for y in w.split(','):
                    du1.append(float(y))
    data=pd.DataFrame(AP_location)
    data.columns=['rp_0','rp_1','ap','rss']
    data=data[data.ap==ap].reset_index()
    f.close()
    X=[]
    Y=[]
    for indexs in data.index:
        ap= data[['rp_0','rp_1']].loc[indexs].tolist()
        rva=data[['rss']].loc[indexs].tolist()
        X.append(ap) #
        Y.append(rva)
    return X,Y