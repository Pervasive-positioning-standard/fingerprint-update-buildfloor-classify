fw = open("D:/vscode/mode3-server/fingerprint_update/1F/fingerprint.txt", 'w')    #将要输出保存的文件地址
rp=[]
ap=[]
rss=[]
for i in data.index:
    if i==0:
       rp[i]=data[['rp_0','rp_1']].iloc[i] 
       ap[i]=data[['ap']].iloc[i]  
       rss[i]=data[['rss1']].iloc[i]     
       fw.write(rp[i][0]+','+rp[i][1]+' '+ ap[i] +','+ rss[i]+' ')    # 将字符串写入文件中
    else:
       rp[i]=data[['rp_0','rp_1']].iloc[i] 
       ap[i]=data[['ap']].iloc[i]  
       rss[i]=data[['rss1']].iloc[i] 
       if rp[i]==rp[i-1]:
          fw.write( ap[i] +','+ rss[i]+' ')
       else:
          fw.write("\n")    # 换行
          fw.write(rp[i][0]+','+rp[i][1]+' '+ ap[i]+','+ rss[i]+' ') 
    i=i+1
fw.close()

    
