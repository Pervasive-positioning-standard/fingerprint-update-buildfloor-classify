import pandas as pd
import numpy as np
import modelfitchange
f= open("D:/vscode/mode3-server/alter_ap.txt", "r")
AP_name=[]
i=0
for x in f:
        i=i+1
        y=x.split(":")
        ap_name=y[0]
        fre=y[1].split(" ")[1]
        if int(fre)>200:
            r=y[1].split(" ")[2][1:-2]
            for w in r.split(","):
                du=[]
                s= w.split('/')
                flo=s[0][1:4]
                lo0=float(s[1].split(';')[0][1:])
                lo1=float(s[1].split(';')[1][:-1])
                #take attention :change the rss difference algorithm.
                rs=float(s[3][:-1])-float(s[2])
                du.append(flo)
                du.append(lo0)
                du.append(lo1)
                du.append(ap_name)
                du.append(rs)
                AP_name.append(du)
data=pd.DataFrame(AP_name)
data.columns=['floor','rp_0','rp_1','ap','rss']
f.close()
g=data.groupby(by='ap')
for a in g:
    apn=a[0]
    f=a[1].groupby(by='floor')
    for fl in f:
         da=fl[1][['rp_0','rp_1','ap','rss']]
         flo2=fl[0]
         print(da)
         print(flo2)
         if len(da)>30:
            modelfitchange.model(da,flo2,apn)

